package bean;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;


public class AddApply {
	
		int userID;
		
		public int getUserID(HttpServletRequest request ) {
			
			HttpSession session=request.getSession(true);
			
			userID=(Integer)session.getAttribute("userID");
			
			System.out.println("userID get  from addApply is :" +userID+"@@@@@@@@@@@");
			//return userID;
			return 3;
		}

		public void setUserID(int userID) {
			this.userID = userID;
		}

		public AddApply(){
			
			/*//HttpServletRequest request=ServletActionContext.getRequest();
			HttpServletRequest request =ServletActionContext.getRequest();
			HttpServletResponse  response=ServletActionContext.getResponse();
			
			HttpSession session=request.getSession(true);
			int userID=(Integer)session.getAttribute("userID");
			System.out.println("**********"+userID);
*/
		}
	
		
		
		
	
	//inpublt userID=(Integer)request.getAttribute("userID");
	
	

}
