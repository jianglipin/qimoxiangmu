package bean;


public class ApplyInfo {//ʱ�������ʽΪyyyy-mm-dd
	private int id;
	private int userID;
	private String reason;
	private String startDate;
	private String endDate;
	private String remark;
	private String appleDate;// ��������ֵ䵥��ƴ�������ݹ淶������appleDate
	private String result;
	private String agreeMan;
	private String agreeDate;

	public ApplyInfo() {

	}

	public ApplyInfo(int id,int userID, String reason,String startDate,
			String endDate, String remark,String appleDate, String result,
			String agreeMan,String agreeDate) {
		this.id=id;
		this.userID = userID;
		this.reason = reason;
		this.startDate = startDate;
		this.endDate = endDate;
		this.remark = remark;
		this.appleDate = appleDate;
		this.result = result;
		this.agreeMan = agreeMan;
		this.agreeDate = agreeDate;
	}
	public int getId()
	{
		return id;
	}
	
	public void setId(int id)
	{
		this.id=id;
	}
	
	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getstartDate() {
		return startDate;
	}

	public void setstartDate(String startDate2) {
		this.startDate = startDate2;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAppleDate() {
		return appleDate;
	}

	public void setAppleDate(String appleDate) {
		this.appleDate = appleDate;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getAgreeMan() {
		return agreeMan;
	}

	public void setAgreeMan(String agreeMan) {
		this.agreeMan = agreeMan;
	}

	public String getAgreeDate() {
		return agreeDate;
	}

	public void setAgreeDate(String agreeDate) {
		this.agreeDate = agreeDate;
	}

}
