package bean;

public class UserInfo // �û���Ϣ��
{

	private int userId;
	private String userName;
	private String password;
	private String department;
	private String id;
	private int age;
	private String sex;
	private String phone;
	private String addresss;
	private String photoUrl;
	private String inDate;

	public UserInfo() {

	}

	public UserInfo(int userID, String userName, String password,
			String department, String id, int age, String sex, String phone,
			String addresss, String photoUrl, String inDate) {
		this.userId = userID;
		this.userName = userName;
		this.password = password;
		this.department = department;
		this.id = id;
		this.age = age;
		this.sex = sex;
		this.phone = phone;
		this.addresss = addresss;
		this.photoUrl = photoUrl;
		this.inDate = inDate;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		System.out.println("this userName:" + userName);
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddresss() {
		return addresss;
	}

	public void setAddresss(String addresss) {
		this.addresss = addresss;

	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

	public String getInDate() {
		return inDate;
	}

	public void setInDate(String inDate) {
		this.inDate = inDate;
	}

}