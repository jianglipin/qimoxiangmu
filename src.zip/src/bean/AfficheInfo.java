package bean;

import java.sql.Date;

public class AfficheInfo {

	private int id;
	private String title;
	private String contment;
	private String promulgator;
	private Date issDate;
	public AfficheInfo()
	{
		
	}
	
	public AfficheInfo(int id,String title,String contment,String promulgator,Date issDate)
	{
		this.id=id;
		this.title=title;
		this.contment=contment;
		this.promulgator=promulgator;
		this.issDate=issDate;
	}
	
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContment() {
		return contment;
	}

	public void setContment(String contment) {
		this.contment = contment;
	}

	public String getPromulgator() {
		return promulgator;
	}

	public void setPromulgator(String promulgator) {
		this.promulgator = promulgator;
	}

	public Date getIssDate() {
		return issDate;
	}

	public void setIssDate(Date date) {
		this.issDate = date;
	}
	
	
}
