package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import dao.DbClient;

import bean.AfficheInfo;

public class AfficheInfoDao {
	
	// �鿴���й�����Ϣ
	public ArrayList<AfficheInfo> selectAll()
	{
		ArrayList<AfficheInfo> list=new ArrayList<AfficheInfo>();
		try
		{
			Connection con= DbClient.getConnection();
			Statement statement =con.createStatement();
			String sql="select * from affiche order by issDate desc";
			ResultSet result=statement.executeQuery(sql);
			while(result.next())
			{
				AfficheInfo aff = new AfficheInfo();
				aff.setId(result.getInt("id"));
				aff.setTitle(result.getString("title"));
				aff.setContment(result.getString("contment"));
				aff.setPromulgator(result.getString("promulgator"));
				aff.setIssDate(result.getDate("issDate"));
				list.add(aff);
			}
			DbClient.closeConnection();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	
	//�鿴ĳ��������Ϣ
	public AfficheInfo selectOne(int id)
	{
		AfficheInfo aff = new AfficheInfo();
		try
		{
			Connection con=DbClient.getConnection();
			Statement statement =con.createStatement();
			String sql="select * from affiche where id="+id+"";
			ResultSet result = statement.executeQuery(sql);
			if(result.next())
			{
				aff.setId(result.getInt("id"));
				aff.setTitle(result.getString("title"));
				aff.setContment(result.getString("contment"));
				aff.setPromulgator(result.getString("promulgator"));
				aff.setIssDate(result.getDate("issDate"));
			}
			DbClient.closeConnection();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return aff;
	}
	
	//����һ��������Ϣ
	public boolean addAffice(AfficheInfo aff)
	{
		boolean isAddAffiche=false;
		try
		{
			Connection con =DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql="insert into affiche(title,contment,promulgator) values('"+aff.getTitle()+"','"+aff.getContment()+"','"+aff.getPromulgator()+"')";
			int falg =statement.executeUpdate(sql);
			if(falg==1)
			{
				isAddAffiche=true;
			}
			DbClient.closeConnection();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isAddAffiche;
	}
	
	//�޸�һ��������Ϣ
	public boolean updateAffiche(AfficheInfo aff)
	{
		boolean isUpdateAffiche=false;
		try
		{
			Connection con =DbClient.getConnection();
			Statement statement =con.createStatement();
			String sql="update affiche set title='"+aff.getTitle()+"',contment='"+aff.getContment()+"',promulgator='"+aff.getPromulgator()+"',issDate=getdate() where id="+aff.getId()+"";
			int falg=statement.executeUpdate(sql);
			if(falg==1)
			{
				isUpdateAffiche=true;
			}
			DbClient.closeConnection();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isUpdateAffiche;
	}
	
	//ɾ��һ��������Ϣ
	public boolean deleteAffiche(int id)
	{
		boolean isDeleteAffiche=false;
		try
		{
			Connection con=DbClient.getConnection();
			Statement statement =con.createStatement();
			String sql="delete from affiche where id="+id+"";
			int falg =statement.executeUpdate(sql);
			if(falg==1)
			{
				isDeleteAffiche=true;
			}
			DbClient.closeConnection();
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isDeleteAffiche;
	}
}
