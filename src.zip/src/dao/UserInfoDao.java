package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.UserInfo;

public class UserInfoDao {

	// �����û�����
	public String getPasssword(int userID, String userName) {
		String password = "����ʧ��!��ȷ��Ա���ź����������ԣ�";
		Connection con = DbClient.getConnection();
		try {

			Statement statement = con.createStatement();
			String sql = "select pwd from users where userID=" + userID
					+ " and userName='" + userName + "'";
			ResultSet result = statement.executeQuery(sql);
			if (result.next()) {
				password = result.getString("pwd");
			}
			DbClient.closeConnection();
			con.close();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return password;
	}

	public UserInfo selectOne(int userID)// ����һ���û���Ϣ
	{
		ResultSet result;
		UserInfo user = new UserInfo();
		Connection con = DbClient.getConnection();

		try {
			Statement state = con.createStatement();
			String sql = "select * from users where userID=" + userID;

			result = state.executeQuery(sql);
			if (result.next()) {

				user.setUserId(result.getInt("userID"));
				user.setUserName(result.getString("userName"));
				user.setPassword(result.getString("pwd"));
				user.setDepartment(result.getString("department"));
				user.setId(result.getString("id"));
				user.setAge(result.getInt("age"));
				user.setSex(result.getString("sex"));
				user.setPhone(result.getString("phone"));
				user.setAddresss(result.getString("addresss"));
				user.setPhotoUrl(result.getString("photoUrl"));
				user.setInDate(result.getString("inDate"));
			}
			result.close();
			state.close();
			DbClient.closeConnection();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return user;
	}

	// �h��һ���Ñ�
	public boolean deleteUser(int userID) {
		boolean isdelete = false;
		try {
			if (selectOne(userID) == null)// ���Д��Ñ��Ƿ���ڣ��������ڄt����false����ֹ�h��
			{
				isdelete = false;
			} else {
				Connection con = DbClient.getConnection();
				Statement statement = con.createStatement();
				String sql = "delete from users where userID=" + userID;
				int flag = statement.executeUpdate(sql);
				if (flag == 1) {
					isdelete = true;

				}
				DbClient.closeConnection();
				con.close();	
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isdelete;
	}

	// ��ԃ�����Ñ���Ϣ
	public ArrayList<UserInfo> selectAll() {
		ArrayList<UserInfo> list = new ArrayList<UserInfo>();
		try {
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "select * from users";
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				UserInfo user = new UserInfo();

				user.setUserId(result.getInt("userID"));
				user.setUserName(result.getString("userName"));
				user.setPassword(result.getString("pwd"));
				user.setDepartment(result.getString("department"));
				user.setId(result.getString("id"));
				user.setAge(result.getInt("age"));
				user.setSex(result.getString("sex"));
				user.setPhone(result.getString("phone"));
				user.setAddresss(result.getString("addresss"));
				user.setPhotoUrl(result.getString("photoUrl"));
				user.setInDate(result.getString("inDate"));
				list.add(user);
			}
			DbClient.closeConnection();
			con.close();	
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return list;
	}

	// ����һ���Ñ�
	public boolean addUser(String userName, String id, int age, String sex,
			String phone, String addresss, String department, String photoUrl,
			String inDate) {
		boolean isadd = false;
		try {
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "insert into [users](userName,id,age,sex,phone,addresss,department,photoUrl,inDate) "
					+ "values('"
					+ userName
					+ "','"
					+ id
					+ "','"
					+ age
					+ "','"
					+ sex
					+ "','"
					+ phone
					+ "','"
					+ addresss
					+ "','"
					+ department + "','" + photoUrl + "','" + inDate + "')";

			int falg = statement.executeUpdate(sql);
			if (falg == 1) {
				isadd = true;
			}
			DbClient.closeConnection();
			con.close();	
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isadd;
	}

	// �����Ñ���Ϣ
	public boolean updateUser(UserInfo user) {
		boolean isUpdate = false;
		try {
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "update users set userName='" + user.getUserName()
					+ "'," + "department='" + user.getDepartment() + "',id='"
					+ user.getId() + "'," + "age=" + user.getAge() + ",sex='"
					+ user.getSex() + "',phone='" + user.getPhone()
					+ "',addresss='" + user.getAddresss() + "',photoUrl='"
					+ user.getPhotoUrl() + "',inDate='" + user.getInDate()
					+ "' where userID=" + user.getUserId() + "";

			int falg = statement.executeUpdate(sql);
			if (falg == 1) {
				isUpdate = true;
			} else {
				isUpdate = false;
			}
			DbClient.closeConnection();
			con.close();	
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isUpdate;
	}

	// �û���¼
	public boolean userLogin(int userID, String password, String department) {
		boolean isexist = false;
		Connection con = DbClient.getConnection();
		try {
			Statement statement = con.createStatement();
			String sql = "select * from users where userID=" + userID
					+ " and pwd='" + password + "' and department='"
					+ department + "'";
			ResultSet result = statement.executeQuery(sql);
			if (result.next()) {
				isexist = true;
			}
			DbClient.closeConnection();
			con.close();		
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return isexist;
	}

	// �޸�����
	public boolean updatePassword(int userID, String password) {
		boolean isUpdatePwd = false;
		try {
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "update users set pwd='" + password
					+ "' where userID=" + userID + "";
			int falg = statement.executeUpdate(sql);
			if (falg == 1) {
				isUpdatePwd = true;
			}
			DbClient.closeConnection();
			con.close();	
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return isUpdatePwd;
	}

	// �������Ա����Ա����
	public int getNewUserID() {
		int newUserID = 0;
		try {
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "select max(userID)+1 from users";
			ResultSet result = statement.executeQuery(sql);
			if (result.next()) {
				newUserID = Integer.parseInt(result.getString(1));
			}
			DbClient.closeConnection();
			con.close();	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newUserID;
	}

}
