package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbClient {
	private static String userName = "sa";
	private static String password = "123";
	private static Connection con = null;

	public static Connection getConnection() {

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		try {
			String uri = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=employeeAdmin";
			con = DriverManager.getConnection(uri, userName, password);

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return con;

	}

	public static void closeConnection() {
		try {
			con.close();
		} catch (Exception ex)

		{
			ex.printStackTrace();
		}

	}

}
