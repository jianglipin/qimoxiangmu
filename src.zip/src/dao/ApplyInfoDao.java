package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.ApplyInfo;

public class ApplyInfoDao {
	
	//�鿴������Ո��Ϣ
	public ArrayList<ApplyInfo> selectAll()
	{
		
		ArrayList<ApplyInfo> list= new ArrayList<ApplyInfo>();
		try
		{
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql="select * from apply";
			ResultSet result= statement.executeQuery(sql);
			while(result.next())
			{
				ApplyInfo apply = new ApplyInfo();
				apply.setId(result.getInt("id"));
				apply.setUserID(result.getInt("userID"));
				apply.setReason(result.getString("reason"));
				apply.setstartDate(result.getString("startDate"));
				apply.setEndDate(result.getString("endDate"));
				apply.setRemark(result.getString("remark"));
				apply.setAppleDate(result.getString("appleDate"));
				apply.setResult(result.getString("result"));
				apply.setAgreeMan(result.getString("agreeMan"));
				apply.setAgreeDate(result.getString("agreeDate"));
				list.add(apply);
			}
			statement.close();
			result.close();
			DbClient.closeConnection();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	//�鿴��ĳλԱ��������Ϣ
	public ApplyInfo selectOneApply(int id)
	{
		
		ApplyInfo apply = new ApplyInfo();
		try
		{
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "select * from apply where id="+id+"";
			ResultSet result = statement.executeQuery(sql);
			if(result.next())
			{	
			
				apply.setId(result.getInt("id"));
				apply.setUserID(result.getInt("userID"));
				apply.setReason(result.getString("reason"));
				apply.setstartDate(result.getString("startDate"));
				apply.setEndDate(result.getString("endDate"));
				apply.setRemark(result.getString("remark"));
				apply.setAppleDate(result.getString("appleDate"));
				apply.setResult(result.getString("result"));
				apply.setAgreeMan(result.getString("agreeMan"));
				apply.setAgreeDate(result.getString("agreeDate"));
			
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return apply;
	}
	
	//����ĳλԱ������������Ϣ
	public ArrayList<ApplyInfo> selectOne(int userID)
	{
		
		ArrayList<ApplyInfo> list= new ArrayList<ApplyInfo>();
		try
		{
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql = "select * from apply where userID="+userID+" order by appleDate desc";
			ResultSet result = statement.executeQuery(sql);
			if(result.next())
			{	
				ApplyInfo apply = new ApplyInfo();
				apply.setId(result.getInt("id"));
				apply.setUserID(result.getInt("userID"));
				apply.setReason(result.getString("reason"));
				apply.setstartDate(result.getString("startDate"));
				apply.setEndDate(result.getString("endDate"));
				apply.setRemark(result.getString("remark"));
				apply.setAppleDate(result.getString("appleDate"));
				apply.setResult(result.getString("result"));
				apply.setAgreeMan(result.getString("agreeMan"));
				apply.setAgreeDate(result.getString("agreeDate"));
				list.add(apply);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	//�����ݼٻ����
	public boolean addApply(ApplyInfo apply)// ע�����ڵĲ����ʽ�ǣ�2010-09-12
	{
		boolean isAdd=false;
		Connection con = DbClient.getConnection();
		try {
			
			String sql="insert into apply(userID,reason,startDate,endDate,remark) values(?,?,?,?,?)";
			PreparedStatement statement = con.prepareStatement(sql);	//ʹ��ͨ���
			statement.setInt(1, apply.getUserID());
			statement.setString(2,apply.getReason());
			statement.setString(3,apply.getstartDate());
			statement.setString(4, apply.getEndDate());
			statement.setString(5, apply.getRemark());
			int falg=statement.executeUpdate();
			if(falg==1)
			{
				isAdd=true;
			}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return isAdd;
		
	}
	
	 //�޸�������Ϣ
	public boolean updateApply(String reason,String startDate,String endDate,String remark,int id)
	{
		boolean isUpdateApply=false;
		try
		{
			Connection con =DbClient.getConnection();
			Statement statement =con.createStatement();
			String sql="update apply set reason='"+reason+"' ,startDate='"+startDate+"',endDate='"+endDate+"',remark='"+remark+"',appleDate=getDate() where id="+id+"";
			int falg=statement.executeUpdate(sql);
			if(falg==1)
			{
				isUpdateApply=true;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return isUpdateApply;
	}
	
	//ɾ��������Ϣ
	public boolean deleteApply(int id)
	{
		boolean isDeleteApply=false;
		try
		{
			Connection con =DbClient.getConnection();
			Statement statement=con.createStatement();
			String sql="delete from apply where id="+id+"";
			int falg=statement.executeUpdate(sql);
			if(falg==1)
			{
				isDeleteApply=true;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return isDeleteApply;
	}
	//��������δ��˵��걨��Ϣ
	public ArrayList<ApplyInfo> selectNoShenHe()
	{
		ArrayList<ApplyInfo> list= new ArrayList<ApplyInfo>();
		try
		{
			Connection con = DbClient.getConnection();
			Statement statement = con.createStatement();
			String sql="select * from apply where agreeMan is null and agreeDate is null ";
			ResultSet result= statement.executeQuery(sql);
			while(result.next())
			{
				ApplyInfo apply = new ApplyInfo();
				apply.setId(result.getInt("id"));
				apply.setUserID(result.getInt("userID"));
				apply.setReason(result.getString("reason"));
				apply.setstartDate(result.getString("startDate"));
				apply.setEndDate(result.getString("endDate"));
				apply.setRemark(result.getString("remark"));
				apply.setAppleDate(result.getString("appleDate"));
				apply.setResult(result.getString("result"));
				apply.setAgreeMan(result.getString("agreeMan"));
				apply.setAgreeDate(result.getString("agreeDate"));
				list.add(apply);
			}
			statement.close();
			result.close();
			DbClient.closeConnection();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}
	
	//���������Ϣ
	public boolean auditApply(String agree,String agreeMan,int id)
	{
		boolean isAuditApply=false;
		try
		{
			Connection con=DbClient.getConnection();
			Statement statement=con.createStatement();
			String sql="update apply set result='"+agree+"',agreeMan='"+agreeMan+"',agreeDate=getdate() where id="+id;
			int falg=statement.executeUpdate(sql);
			if(falg==1)
			{
				isAuditApply=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isAuditApply;
	}
	
}
