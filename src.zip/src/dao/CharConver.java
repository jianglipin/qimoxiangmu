package dao;

public class CharConver {
		//���ֽ���ת���ɺ���
	public String converToGB(String str)
	{
		String keyword=str.trim();
		try
		{
			byte bb[]=keyword.getBytes("ISO-8859-1");
			keyword=new String(bb,"gb2312");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return keyword;
	}

}
