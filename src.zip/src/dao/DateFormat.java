package dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormat {

	/**
	 * @param args
	 */
	public Date dateDay(String str)//ת����������
	{
		Date date = null;
		try
		{
			SimpleDateFormat format1=new SimpleDateFormat("yyyy-mm-dd");
			date=format1.parse(str);
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		return date;
	}
	
	public Date dateHH(String str)////ת�������¾�ȷ��Сʱ
	{
		Date date = null;
		try
		{
			SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd hh:mm");
			date=format.parse(str);
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		return date;
	}
	
/*	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleDateFormat format1=new SimpleDateFormat("yyyy-mm-dd");
		SimpleDateFormat format2=new SimpleDateFormat("yyyy-mm-dd hh:mm");
		
		String str1="2008-09-09";
		String str2="2023-12-12 09:34";
		
		try {
			Date date1=format1.parse(str1);
			Date date2=format2.parse(str2);
			System.out.println("date1="+date1+"  date2= "+date2);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
	}*/

}
