package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserInfoDao;

public class AddEmpServlet extends HttpServlet {

	/**
	 * ������Ա��
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("gb2312");
		UserInfoDao userDao = new UserInfoDao();
		int userID=userDao.getNewUserID();//���������Ա����Ա����
		// ��ȡ������Ϣ
		String userName = request.getParameter("userName");
		String department = request.getParameter("department");
		String sex = request.getParameter("sex");
		int age = Integer.parseInt(request.getParameter("age").trim());
		String id = request.getParameter("id");
		String phone = request.getParameter("phone");
		String inDate = request.getParameter("inDate");
		String photoUrl = request.getParameter("photoUrl");
		String addresss = request.getParameter("addresss");
		boolean isAdd=userDao.addUser(userName, id, age, sex, phone, addresss, department, photoUrl, inDate);
		if(isAdd)
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/addEmp.jsp';alert('��Ա�����ӳɹ�����Ա������"+userID+",Ĭ��������888888)');</script>");
		}
		else
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/addEmp.jsp';alert('��Ա������ʧ�ܣ������ԣ�');</script>");
		}

	}

	public void init() throws ServletException {
		// Put your code here
	}

}
