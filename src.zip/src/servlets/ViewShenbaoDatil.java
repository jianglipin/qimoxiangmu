package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import bean.ApplyInfo;
import dao.ApplyInfoDao;

public class ViewShenbaoDatil extends HttpServlet {

	/**
	 *�鿴������ϸ��Ϣ�����ṩ�޸ĺ�ɾ������
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ��
		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		ApplyInfoDao appDao = new ApplyInfoDao();
		ApplyInfo app = new ApplyInfo();

		
		int id =Integer.parseInt(request.getParameter("id"));
		app=appDao.selectOneApply(id);
		//���Ͳ�ѯ��Ϣ

		RequestDispatcher dispatcher = request
		.getRequestDispatcher("../login/kaoqin/ViewShengbaoDatil.jsp?id="
				+ app.getId() + "&userID=" + app.getUserID() + "&reason="
				+ app.getReason() + "&startDate=" + app.getstartDate() + "&endDate="
				+ app.getEndDate() + "&remark=" + app.getRemark() + "&appleDate=" + app.getAppleDate() + "&result=" + app.getResult()
				+ "&agreeMan=" + app.getAgreeMan() + "&agreeDate=" + app.getAgreeDate());
		dispatcher.forward(request, response);
	
	}

	public void init() throws ServletException {
		
	}

}
