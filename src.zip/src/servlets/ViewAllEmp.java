package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserInfo;

import dao.UserInfoDao;

public class ViewAllEmp extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * Destruction of the //�鿴����ְ����Ϣ
	 */
	public void destroy() {
		super.destroy(); 
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ������ȡ����Ա����Ϣ
		request.setCharacterEncoding("gb2312");
		StringBuffer str = new StringBuffer();
		UserInfoDao userDao =new UserInfoDao();
		ArrayList<UserInfo> list =new ArrayList<UserInfo>();
		list=userDao.selectAll();
		for(int i=0;i<list.size();i++)
		{
			str.append("<tr><td>");
			str.append(list.get(i).getUserId()+"</td><td width='55px'>");
			str.append(list.get(i).getUserName()+"</td><td>");
			str.append(list.get(i).getDepartment()+"</td><td>");
			str.append(list.get(i).getAge()+"</td><td>");
			str.append(list.get(i).getSex()+"</td><td>");
			str.append(list.get(i).getPhone()+"</td><td>");
			str.append(list.get(i).getId()+"</td><td>");
			str.append(list.get(i).getAddresss()+"</td><td width='100px'>");
			str.append(list.get(i).getInDate()+"</td><td>");
			str.append("<font size='+1' color='orange'><a href='../servlet/EmpInfoDetail?userID="+list.get(i).getUserId()+"'>��ϸ/�޸���Ϣ</a></font></td></tr>");
		}
		request.setAttribute("str", str);
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("../login/kaoqin/ViewAllEmp.jsp");
		dispatcher.forward(request, response);

	}

	public void init() throws ServletException {
		// Put your code here
	}

}
