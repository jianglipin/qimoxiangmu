package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AfficheInfoDao;

import bean.AfficheInfo;

public class ViewGongao extends HttpServlet {

	/**
	 * �鿴������Ϣ
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy();
	}

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

			doPost(request,response);
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ����ù�����󼯺�
		AfficheInfoDao affDao = new AfficheInfoDao();
		ArrayList<AfficheInfo> list=new ArrayList<AfficheInfo>();
		list=affDao.selectAll();
		StringBuffer str=new StringBuffer();
		for(int i=0;i<5;i++)
		{
			str.append("<br>"+"����ţ�"+list.get(i).getId()+"<h4>[��������] "+list.get(i).getTitle()+"</h4>");
			str.append("�������ݣ�"+list.get(i).getContment());
			str.append("<div align='right'>�����ˣ�"+list.get(i).getPromulgator()+"<br>�������ڣ�"+list.get(i).getIssDate()+"</div><hr size='2px' width='90%' color='orange'>");
		}
		
		response.setContentType("text/html;charset=gb2312;");
		response.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>�鿴����</TITLE></HEAD>");
		out.println("  <BODY  bgcolor='#FFFFCC' style='size='15px'>"+str);
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}


	public void init() throws ServletException {
		// Put your code here
	}

}
