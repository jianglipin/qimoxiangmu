package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ApplyInfo;

import dao.ApplyInfoDao;

public class OperShengbao extends HttpServlet {

	/**
	 * ����������Ϣ��ɾ�����޸ģ�
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		int oper=Integer.parseInt(request.getParameter("oper"));//����1Ϊɾ��0Ϊ�޸�
		ApplyInfoDao appDao = new ApplyInfoDao();
	
		//ɾ��
		if(oper==1)
		{
			boolean isDel=appDao.deleteApply(id);
			if(isDel)
			{
				out.print("<script>window.location.href='/servlet/ViewShengbao';alert(����ɾ���ɹ���);</script>");
			}
			else
			{
				out.print("<script>window.location.href='/servlet/ViewShenbaoDatil';alert(����ɾ��ʧ�ܣ�);</script>");
			}
		}
		else//�޸�����
		{
			ApplyInfo app = new ApplyInfo();			
			app=appDao.selectOneApply(id);
			//���Ͳ�ѯ��Ϣ
			RequestDispatcher dispatcher = request
			.getRequestDispatcher("../login/kaoqin/modiftyShenbao.jsp?id="
					+ app.getId() + "&reason="
					+ app.getReason() + "&startDate=" + app.getstartDate() + "&endDate="
					+ app.getEndDate() + "&remark=" + app.getRemark() );
			dispatcher.forward(request, response);
		}
	}


	public void init() throws ServletException {
		// Put your code here
	}

}
