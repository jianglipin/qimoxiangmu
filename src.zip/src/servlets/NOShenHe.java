package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ApplyInfo;
import bean.UserInfo;
import dao.ApplyInfoDao;
import dao.UserInfoDao;

public class NOShenHe extends HttpServlet {

	/**
	 * ����δ���������Ϣ
	 */
	private static final long serialVersionUID = 1L;

	
	public void destroy() {
		super.destroy(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ����ȡ����δ��˵��걨��Ϣ
		response.setContentType("text/html;charset=gb2312;");
		ArrayList<ApplyInfo> list = new ArrayList<ApplyInfo>();
		ApplyInfoDao appDao = new ApplyInfoDao();
		UserInfoDao userDao = new UserInfoDao();
		UserInfo user = new UserInfo();
		StringBuffer str = new StringBuffer();
		list = appDao.selectNoShenHe();
		if(list.size()>=1)
		{
		for(int i=0;i<list.size();i++)
		{
			str.append("<tr><td>");
			int id=list.get(i).getId();
			str.append(id+"</td><td>");//������
			int userID=list.get(i).getUserID();
			user=userDao.selectOne(userID);							
			str.append(user.getUserName()+"</td><td  >");
			str.append(user.getDepartment()+"</td><td width='90px'>");
			str.append(list.get(i).getstartDate()+"</td><td  width='90px'>");
			str.append(list.get(i).getEndDate()+"</td><td  width='100px'>");
			str.append(list.get(i).getReason()+"</td><td>");
			str.append(list.get(i).getRemark()+"</td><td  width='90px'>");
			str.append(list.get(i).getAppleDate()+"</td><td>");
			str.append(list.get(i).getResult()==null?"������":list.get(i).getResult()+"</td><td>");
			str.append(" <td><form action='/employeeAdmin/servlet/ShenHeApply?id="+id+"&result=1' name='shform' method='post'>" +
					"<input type='submit' value=' ��׼ '> </form>" +
					"<form action='/employeeAdmin/servlet/ShenHeApply?id="+id+"&result=0' name='shform' method='post'>" +
					"<input type='submit' value=' ����׼ '> </form></td></tr>");
		}
		}
		else
		{
			str.append("<font color='red' size='+2'>Ŀǰ���е����붼�Ѿ���˹��ˣ�</font>");
		}	
		request.setAttribute("str", str);
		RequestDispatcher dispatcher = request.getRequestDispatcher("../login/kaoqin/NOShenHe.jsp");
		dispatcher.forward(request, response);


	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
		
	}
	
	public void init() throws ServletException {
		
	}

}
