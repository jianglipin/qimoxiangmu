package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ApplyInfoDao;

public class ModifyShengbao extends HttpServlet {

	/**
	 * ִ���޸�����
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		response.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		ApplyInfoDao appDao =new ApplyInfoDao();
		
		int id=Integer.parseInt(request.getParameter("id"));
		String startDate =request.getParameter("startDate");
		String endDate=request.getParameter("endDate");
		String reason=request.getParameter("reason");
		String remark=request.getParameter("remark");
		
		//ִ�и��£��޸ģ�
		boolean isUpdate=appDao.updateApply( reason, startDate, endDate, remark, id);
		if(isUpdate)
		{
			out.print("<script>window.location.href='../servlet/ViewShengbao';alert('���������Ϣ�޸ĳɹ���');</script>");
		}
		else
		{
			out.print("<script>window.location.href='/employeeAdmin/login/kaoqin/modiftyShenbao.jsp';alert('���������Ϣ�޸�ʧ�ܣ�');</script>");
		}
		
	}


	public void init() throws ServletException {
		// Put your code here
	}

}
