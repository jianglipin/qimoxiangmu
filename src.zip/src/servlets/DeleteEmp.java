package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserInfoDao;

public class DeleteEmp extends HttpServlet {

	/**
	 *ɾ��Ա��
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312;");
		PrintWriter out = response.getWriter();
		int userID=Integer.parseInt(request.getParameter("userID"));
		UserInfoDao userDao = new UserInfoDao();
		boolean isDelete =userDao.deleteUser(userID);
		String result="ְ����Ϊ "+userID+" ��Ϣɾ��ʧ��!";
		if(isDelete)
		{
			result="ְ����Ϊ "+userID+"��������Ϣɾ���ɹ���";
		}
		out.println("<script>window.location.href='/employeeAdmin/servlet/ViewAllEmp';alert('"+result+"');</script>");
		
	}

	
	public void init() throws ServletException {
		// Put your code here
	}

}
