package servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserInfo;
import dao.UserInfoDao;

public class ShowModEmpInfo extends HttpServlet {

	/**
	 * ��ʾ��Ҫ�޸�ְ����Ϣ
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		int userID = Integer.parseInt(request.getParameter("userID"));//��ȡԱ����
		UserInfo user = new UserInfo();
		UserInfoDao userdao = new UserInfoDao();
		user = userdao.selectOne(userID);
		// ��ȡ������Ϣ
		String userName = user.getUserName();
		String department = user.getDepartment();
		String sex = user.getSex();
		int age = user.getAge();
		String id = user.getId();
		String phone = user.getPhone();
		String inDate = user.getInDate();
		String addresss = user.getAddresss();
		String photoUrl = user.getPhotoUrl();
	// �D�l��ͨ�^url��ֵ���^ȥ
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("../login/kaoqin/modifyEmpInfo.jsp?userID="
						+ userID + "&userName=" + userName + "&photoUrl="
						+ photoUrl + "&department=" + department + "&sex="
						+ sex + "&age=" + age + "&id=" + id + "&phone=" + phone
						+ "&inDate=" + inDate + "&addresss=" + addresss);
		dispatcher.forward(request, response);
	}


	public void init() throws ServletException {
		// Put your code here
	}

}
