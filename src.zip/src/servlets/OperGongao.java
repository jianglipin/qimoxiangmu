package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AfficheInfo;
import dao.AfficheInfoDao;

public class OperGongao extends HttpServlet {

	/**
	 * ��ȡ������Ϣ���ṩɾ���޸Ĺ���
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ����ù�����󼯺�
		AfficheInfoDao affDao = new AfficheInfoDao();
		ArrayList<AfficheInfo> list=new ArrayList<AfficheInfo>();
		list=affDao.selectAll();
		StringBuffer str=new StringBuffer();
		for(int i=0;i<5;i++)
		{   int id=list.get(i).getId();
			str.append("<br>"+"����ţ�"+id+"<h4>[��������] "+list.get(i).getTitle()+"</h4>");
			str.append("�������ݣ�"+list.get(i).getContment());
			str.append("<div align='right'>�����ˣ�"+list.get(i).getPromulgator()+"<br>�������ڣ�"+list.get(i).getIssDate()+"</div><hr size='2px' width='90%' color='orange'>");
    		str.append("<table align='center' ><tr><td><form action='../servlet/ManageGongao' method='post'>" +
						"<input type='submit' value=' ɾ������ '><input type='hidden' value= '1' name='result'><input type='hidden' value= '"+id+"' name='id'></form></td>");
			str.append("<td><form action='../servlet/ManageGongao' name='shform' method='post'>" +
						"<input type='submit' value=' �޸Ĺ��� '> <input type='hidden' value= '0' name='result'><input type='hidden' value= '"+id+"' name='id'></form></td></tr></table>");
		}
		request.setAttribute("str", str);
		
		RequestDispatcher dispatcher =request.getRequestDispatcher("../login/kaoqin/operGongao.jsp");
		dispatcher.forward(request, response);

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				doPost(request,response);
	}


	public void init() throws ServletException {
		// Put your code here
	}

}
