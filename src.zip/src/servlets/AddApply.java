package servlets;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ApplyInfo;

import dao.ApplyInfoDao;

public class AddApply extends HttpServlet {

	/**
	 *����һ����������
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		PrintWriter out=response.getWriter();
		ApplyInfoDao appDao=new ApplyInfoDao();
		ApplyInfo app=new ApplyInfo();
		HttpSession session=request.getSession(true);
		//��ȡ�ύ������Ϣ
		String start=request.getParameter("startDate");
		String end=request.getParameter("endDate");
		String startTime=request.getParameter("startTime");
		String endTime=request.getParameter("endTime");
		//ʱ��ϲ�
		String startDate=start+startTime;
		String endDate=end+endTime;
		//����beean
		app.setUserID((Integer)session.getAttribute("userID"));
		app.setstartDate(startDate);
		app.setEndDate(endDate);
		app.setRemark(request.getParameter("remark"));
		app.setReason(request.getParameter("reason"));
		
		//�������ݿ�
		boolean isAdd=appDao.addApply(app);
		if(isAdd)
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/shenbao.jsp';alert('�걨�ɹ���');</script>");			
		}
		else
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/shenbao.jsp';alert('��Ǹ���걨ʧ�ܣ��������԰ɣ�');</script>");
		}
		
		//System.out.println(userID+userName+start+end+startDate+endDate+remark+reason);
		
	}

	public void init() throws ServletException {
		
	}

}
