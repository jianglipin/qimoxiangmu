package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ApplyInfoDao;

import bean.ApplyInfo;

public class ViewShengbao extends HttpServlet {

	/**
	 *�鿴����������Ϣ
	 */
	private static final long serialVersionUID = 1L;

	
	public void destroy() {
		super.destroy();
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ʼ����ȡ�걨��Ϣ
		ArrayList<ApplyInfo> list = new ArrayList<ApplyInfo>();
		ApplyInfoDao appDao = new ApplyInfoDao();
		StringBuffer str = new StringBuffer();
		HttpSession session =request.getSession(true);
		int userID=(Integer)session.getAttribute("userID");
		list = appDao.selectOne(userID);
		if(list.size()>=1)
		{
		for(int i=0;i<list.size();i++)
		{
			str.append("<tr><td>");
			int id=list.get(i).getId();
			str.append(id+"</td><td>");
			str.append(list.get(i).getUserID()+"</td><td  width='100px'>");
			str.append(list.get(i).getstartDate()+"</td><td  width='100px'>");
			str.append(list.get(i).getEndDate()+"</td><td  width='100px'>");
			str.append(list.get(i).getReason()+"</td><td>");
			
			str.append(list.get(i).getRemark()+"</td><td  width='100px'>");
			str.append(list.get(i).getAppleDate()+"</td><td>");
			String state=list.get(i).getResult()==null?"�����":list.get(i).getResult();//����״̬
			str.append(state+"</td><td>");
			str.append("<font size='+1' color='orange'><a href='../servlet/ViewShenbaoDatil?id="+id+"'>��ϸ/�޸���Ϣ</a></font></td></tr>");
		}
		}
		else
		{
			str.append("<font size='+2' color='red'>��Ŀǰ��û�������������</font>");
		}	
		
		//������ҳ
		response.setContentType("text/html;charset=gb2312;");
		PrintWriter out = response.getWriter();
		response.setCharacterEncoding("gb2312");
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY  bgcolor='#FFFFCC'>");
		out.println(" ");
		out.println("<div ><p align='center' style='color:#CC3300;  font-size:24px; '>���������ѯ��</p></div>");
		out.println(" <table border='1px' align='center'");		
		out.println("<tr><th>����ID</th><th>Ա����</th><th  width='100px' >��ʼʱ��</th><th width='100px'>����ʱ��</th><th  width='200px'>����ԭ��</th><th>��������</th><th  width='100px'>����ʱ��</th><th>������</th><th>����</th></tr>");
		out.println(str);
		out.println("</table>");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request,response);
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
