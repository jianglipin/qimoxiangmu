package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.AfficheInfo;

import dao.AfficheInfoDao;

public class UpdateGongao extends HttpServlet {

	/**
	 * ִ�и��¹�����Ϣ
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		AfficheInfoDao affDao = new AfficheInfoDao();
		AfficheInfo aff = new AfficheInfo();

		aff.setId(Integer.parseInt(request.getParameter("id")));
		aff.setTitle(request.getParameter("title"));
		aff.setContment(request.getParameter("contment"));
		aff.setPromulgator(request.getParameter("department"));

		boolean isUpdate = affDao.updateAffiche(aff);
		if (isUpdate) {
			out.println("<script>window.location.href='/employeeAdmin/servlet/OperGongao';alert('������Ϣ�޸ĳɹ�!');</script>");
		} else {
			out.println("<script>window.location.href='/employeeAdmin/servlet/OperGongao';alert('������Ϣ�޸�ʧ��!');</script>");
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void init() throws ServletException {

	}

}
