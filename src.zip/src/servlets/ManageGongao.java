package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.AfficheInfo;

import dao.AfficheInfoDao;

public class ManageGongao extends HttpServlet {

	/**
	 * �������棨ɾ���͸��£�
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		PrintWriter out=response.getWriter();
		//��ȡֵ
		
		int id=Integer.parseInt(request.getParameter("id"));//������
		int temp = Integer.parseInt(request.getParameter("result"));//Ϊ0��1��0��ɾ��1�����¹��棩		
		//ִ��ɾ��������ת�����޸Ĺ���ҳ��
		AfficheInfoDao affDao = new AfficheInfoDao();
		AfficheInfo aff = new AfficheInfo();
		if(temp==1)//ɾ������
		{
			boolean isDel=affDao.deleteAffiche(id);
			if(isDel)
			{
				out.print("<script>window.location.href='/employeeAdmin/servlet/OperGongao';alert('ɾ������ɹ���')</script>");
				}	
			else
			{
				out.print("<script>window.location.href='/employeeAdmin/servlet/OperGongao';alert('ɾ������ʧ�ܣ�')</script>");
			}
		}
		else//�޸Ĺ�����Ϣ
		{
			aff=affDao.selectOne(id);
			RequestDispatcher dispatcher =request.getRequestDispatcher(
					"/login/kaoqin/mondiftyGongao.jsp?id="+aff.getId()+
					"&title="+aff.getTitle()+"&contment="+aff.getContment()+"");
			dispatcher.forward(request, response);
		}		
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doGet(request,response);		
	}

	public void init() throws ServletException {
		
	}

}
