package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AfficheInfoDao;

import bean.AfficheInfo;

public class FabugonggaoServlet extends HttpServlet {

	/**
	 * ��������servlet
	 */
	private static final long serialVersionUID = 1L;

	
	public void destroy() {
		super.destroy(); 
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		response.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		AfficheInfo aff=new AfficheInfo();
		AfficheInfoDao affDao=new AfficheInfoDao();
		//��ȡҪ����������Ϣ
		aff.setTitle(request.getParameter("title").trim());
		aff.setContment(request.getParameter("contment").trim());
		aff.setPromulgator(request.getParameter("department"));			
		boolean isAdd=affDao.addAffice(aff);
		if(isAdd)
		{
			out.println("<script>window.location.href='/employeeAdmin/servlet/OperGongao';alert('��ϲ�����淢���ɹ���');</script>");
		}
		else
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/fabugonggao.jsp';alert(�����,���淢��ʧ�ܣ������԰ɣ�');</script>");
		}
		
	}	
	public void init() throws ServletException {
		// Put your code here
	}

}
