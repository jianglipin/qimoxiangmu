package servlets;

import dao.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.UserInfo;

@SuppressWarnings("serial")
// �û���¼��֤
public class LoginServlet extends HttpServlet {

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312");
		HttpSession session = request.getSession(true);
		// ��������
		CharConver conver = new CharConver();
		UserInfoDao user = new UserInfoDao();

		int userID = Integer.parseInt(request.getParameter("userID").trim());// uerID
		String password = request.getParameter("password");// login password
		String dep = request.getParameter("department").trim();// user

		// ��ʽ��������ת�ɺ��֣�
		String department = conver.converToGB(dep).trim();		

		// �ж��û��Ƿ���ڼ���¼�Ƿ�ɹ�
		if (user.userLogin(userID, password, department)) {
			// ����¼��Ϣ����session
			session.setAttribute("userID", new Integer(userID));
			session.setAttribute("password", password);
			session.setAttribute("department", department);
			UserInfo userInfo=user.selectOne(userID);
					
			session.setAttribute("userName",userInfo.getUserName());
			if(department.equals("���²�"))
			{
			response.sendRedirect("../login/mainPage.jsp");
			}
			else if(department.equals("ְ��"))
			{
				response.sendRedirect("../login/staffIndex.jsp");
			}
			else if(department.equals("�쵼"))
			{
				response.sendRedirect("../login/leaderIndex.jsp");
			}
			else if(department.equals("����Ա"))
			{
				response.sendRedirect("../login/adminIndex.jsp");
			}	
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>window.location.href='../index.jsp';alert('��¼ʧ�ܣ���ȷ���ʺź���������ԣ�');</script>");
		}
	
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
