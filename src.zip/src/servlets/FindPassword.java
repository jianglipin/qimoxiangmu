package servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserInfoDao;

public class FindPassword extends HttpServlet {

	/**
	 *�����û�����
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		RequestDispatcher dispatcher =request.getRequestDispatcher("../login/kaoqin/findPassword.jsp");
		int userID=Integer.parseInt(request.getParameter("userID"));
		String userName=request.getParameter("userName");
		UserInfoDao userDao = new UserInfoDao();
		String password=userDao.getPasssword(userID, userName);
		request.setAttribute("userID", userID);
		request.setAttribute("userName", userName);
		request.setAttribute("password", password);//���ò���������
		
		dispatcher.forward(request, response);
		

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request,response);
	}

	public void init() throws ServletException {
	
	}

}
