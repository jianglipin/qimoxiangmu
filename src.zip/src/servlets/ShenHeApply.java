package servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ApplyInfoDao;

public class ShenHeApply extends HttpServlet {

	/**
	 * ���������Ϣ
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//��ȡֵ
		HttpSession session = request.getSession(true);
		String agreeMan = (String) session.getAttribute("userName");
		int temp = Integer.parseInt(request.getParameter("result"));
		String result = null;
		if (temp == 1) {
			result = "��׼";
		} else if (temp == 0) {
			result = "����׼";
		}
		int id = Integer.parseInt(request.getParameter("id"));
		ApplyInfoDao app = new ApplyInfoDao();
		boolean isShenHe = false;
		//д�����ݿ�
		if (result != null) {
			isShenHe = app.auditApply(result, agreeMan, id);
		}	
		if (isShenHe) {
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/servlet/NOShenHe");
			dispatcher.forward(request, response);
		}		
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
