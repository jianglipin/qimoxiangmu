package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserInfo;

import dao.UserInfoDao;

public class UpdateEmpInfo extends HttpServlet {

	/**
	 *ִ��ְ����Ϣ����
	 */
	private static final long serialVersionUID = 1L;

	public void destroy() {
		super.destroy(); 
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312;");
		request.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		UserInfoDao userDao = new UserInfoDao();
		UserInfo user = new UserInfo();
		int userID=Integer.parseInt(request.getParameter("userID"));
		
		System.out.println("upadate userID is:"+userID);
		user.setUserId(userID);
		user.setUserName(request.getParameter("userName"));
		user.setDepartment(request.getParameter("department"));
		user.setSex(request.getParameter("sex"));
		user.setAge(Integer.parseInt(request.getParameter("age").trim()));
		user.setId(request.getParameter("id"));
		user.setPhone(request.getParameter("phone"));
		user.setInDate(request.getParameter("inDate"));
		user.setPhotoUrl(request.getParameter("photoUrl"));
		user.setAddresss(request.getParameter("addresss"));
		boolean isAdd=userDao.updateUser(user);
		if(isAdd)
		{
			out.println("<script>window.location.href='/employeeAdmin/servlet/ViewAllEmp';alert('ְ����Ϊ"+userID+"����Ϣ�޸ĳɹ�!');</script>");
		}
		else
		{
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/modifyEmpInfo.jsp';alert('��Ϣ�޸�ʧ�ܣ������ԣ�');</script>");
		}

	}

	public void init() throws ServletException {
		// Put your code here
	}

}
