package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserInfoDao;

public class MondifyPwdServlet extends HttpServlet {

	/**
	 * �޸�����
	 */
	private static final long serialVersionUID = 1L;
	public void destroy() {
		super.destroy();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=gb2312;");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);

		String newpwd = request.getParameter("newpwd").trim();//�����������
		String inOldpwd = request.getParameter("oldpwd").trim();//����ľ�����
		int userID = (Integer) session.getAttribute("userID");
		String loginpwd = (String) session.getAttribute("password");//��ǰ�ĵ�¼ʱ������
		System.out.println(userID +"	newpwd  "+loginpwd+"	newpwd:"+ newpwd + " inoldpwd " + inOldpwd);
		
		if (!inOldpwd.equals(loginpwd)) {
			out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/modifyPwd.jsp';alert('�����������ȷ�Ϻ������ԣ�');</script>");
		} else

		{
			UserInfoDao user = new UserInfoDao();
			boolean isMidify = user.updatePassword(userID, newpwd);
			if (isMidify) {
				out.println("<script>	alert('��ϲ�㣬�����޸ĳɹ���');</script>");

			} else {			
				out.println("<script>window.location.href='/employeeAdmin/login/kaoqin/modifyPwd.jsp';alert('�ޣ�����⣡�����޸�ʧ�ܣ������԰ɣ���');</script>");

			}
		}

	}

	public void init() throws ServletException {
		// Put your code here
	}

}
