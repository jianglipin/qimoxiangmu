package business;



import java.util.ArrayList;

import dao.AfficheInfoDao;


import dao.UserInfoDao;
import bean.AfficheInfo;



public class Test {

	/**
	 * @pasjargs
	 */
	public static void main(String[] args) {
	
	UserInfoDao usDao = new UserInfoDao();
	int a=usDao.getNewUserID();
	System.out.println("next userID is:"+a);
			

	/*	UserInfo userInfo=usDao.selectOne(1001);//��ԃһ���Ñ���Ϣ��������
		System.out.println(userInfo.getUserName()+userInfo.getUserId());
		
		ArrayList<UserInfo> list = new ArrayList<UserInfo>();// ���������Ñ���Ϣ
		list=usDao.selectAll();
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i).getUserId());
			
		}
		*/
		
		
	/*	//�鿴����������Ϣ
		ApplyInfoDao apply=new ApplyInfoDao();
		ArrayList<ApplyInfo> lsApp = new ArrayList<ApplyInfo>();
		lsApp=apply.selectAll();
		for(int i=0;i<lsApp.size();i++)
		{
			System.out.println(lsApp.get(i).getId());
			
		}*/
		
	////�û���¼
		//usDao.updateUser(userInfo);
		boolean us=usDao.userLogin(1001, "zoukang", "ְ��");
		//System.out.println(us.getAddresss()+"		seled login");
		//System.out.println(us.getPassword());
		System.out.println("have this user?:  "+us);
		
		/*	
		//updatePassWord
		boolean falg=usDao.updatePassword(1001, "zoukang");
		if(falg==true)
		{
			System.out.println("password update success!");
		}
		else
		{
			System.out.println("password update fail");
		}
		*/

		
		
		///////////////////���ڹ������///////////////
		AfficheInfoDao affDao = new AfficheInfoDao();
		AfficheInfo aff = new AfficheInfo();
		ArrayList<AfficheInfo> ltaff= new ArrayList<AfficheInfo>();//selectAll
		ltaff=affDao.selectAll();
		for(int i=0;i<ltaff.size();i++)
		{
			System.out.println(ltaff.get(i).getId());
			
		}
		
		//selectOne
		aff=affDao.selectOne(1);
		System.out.println("seltecOne()	"+aff.getContment());
		
		//addAffiche 
	
		
	}

}
